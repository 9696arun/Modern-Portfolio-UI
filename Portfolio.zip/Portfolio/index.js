
    const $  = (sel, ctx=document) => ctx.querySelector(sel);
    const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));
    const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));

    // Year
    $('#year').textContent = new Date().getFullYear();

    // In-view animation
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('inview'); });
    }, {rootMargin: '0px 0px -10% 0px', threshold:.1});
    $$('.card').forEach(c => io.observe(c));

    // Video hover preview (if video used inside .thumb)
    $$('.thumb video').forEach(v => {
      v.addEventListener('mouseenter', () => { v.currentTime = 0; v.play().catch(()=>{}); });
      v.addEventListener('mouseleave', () => { v.pause(); });
    });

    // ---------- State ----------
    const gallery    = $('#gallery');
    const chips      = $$('.chip[data-filter]');
    const search     = $('#search');
    const noResults  = $('#noResults');
    const sortSel    = $('#sort');
    const shareView  = $('#shareView');
    const resultCount= $('#resultCount');

    let activeFilter = 'all';
    let keyword      = '';
    let sortMode     = 'recent';

    // Restore from URL/localStorage
    (function initStateFromURL(){
      const params = new URLSearchParams(location.search);
      activeFilter = params.get('cat')  || localStorage.getItem('ek-cat')  || 'all';
      keyword      = params.get('q')    || localStorage.getItem('ek-q')    || '';
      sortMode     = params.get('sort') || localStorage.getItem('ek-sort') || 'recent';

      // Apply UI
      chips.forEach(c => c.classList.toggle('active', c.dataset.filter === activeFilter));
      search.value = keyword;
      sortSel.value = sortMode;
    })();

    // Keyboard shortcuts
    window.addEventListener('keydown', (e)=>{
      if(e.key === '/' && document.activeElement !== search){
        e.preventDefault(); search.focus();
      }
      if(e.key === 'ArrowUp' || e.key === 'ArrowDown'){
        const modes = ['recent','oldest','alpha','zalpha'];
        let idx = modes.indexOf(sortSel.value);
        if(e.key === 'ArrowUp')   idx = (idx - 1 + modes.length) % modes.length;
        if(e.key === 'ArrowDown') idx = (idx + 1) % modes.length;
        sortSel.value = modes[idx]; sortCards(sortSel.value); updateStateAndURL();
      }
    });

    // Category counts
    function updateCategoryCounts(){
      const counts = {};
      $$('.card', gallery).forEach(c => { counts[c.dataset.cat] = (counts[c.dataset.cat]||0) + 1; counts['all']=(counts['all']||0)+1; });
      chips.forEach(ch => {
        const base = ch.textContent.replace(/\s*\(\d+\)\s*$/,'');
        const n = counts[ch.dataset.filter] || 0;
        ch.textContent = `${base} (${n})`;
      });
    }
    updateCategoryCounts();

    // Filtering + Search
    function applyFilters(){
      const cards = $$('.card', gallery);
      let visible = 0;
      const kw = (search.value || '').trim().toLowerCase();
      cards.forEach(card => {
        const matchCategory = activeFilter === 'all' || card.dataset.cat === activeFilter;
        const hay = `${card.dataset.title} ${card.dataset.tags} ${card.dataset.cat}`.toLowerCase();
        const matchKw = !kw || hay.includes(kw);
        const show = matchCategory && matchKw;
        card.style.display = show ? '' : 'none';
        if(show) visible++;
      });
      noResults.style.display = visible ? 'none' : '';
      resultCount.textContent = `${visible} project${visible===1?'':'s'} shown`;
      return visible;
    }

    chips.forEach(chip => chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeFilter = chip.dataset.filter;
      applyFilters();
      sortCards(sortSel.value);
      updateStateAndURL();
    }));

    $('#resetFilters').addEventListener('click', ()=>{
      activeFilter='all'; search.value='';
      chips.forEach(c=>c.classList.toggle('active', c.dataset.filter==='all'));
      applyFilters(); sortCards(sortSel.value); updateStateAndURL();
    });

    let debounce;
    search.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => { applyFilters(); sortCards(sortSel.value); updateStateAndURL(); }, 120);
    });

    // Sorting
    sortSel.addEventListener('change', () => { sortCards(sortSel.value); updateStateAndURL(); });
    function sortCards(mode){
      const all = $$('.card', gallery);
      const sorted = [...all].sort((a,b) => {
        if(mode === 'alpha')  return a.dataset.title.localeCompare(b.dataset.title);
        if(mode === 'zalpha') return b.dataset.title.localeCompare(a.dataset.title);
        if(mode === 'oldest') return new Date(a.dataset.date) - new Date(b.dataset.date);
        // recent
        return new Date(b.dataset.date) - new Date(a.dataset.date);
      });
      sorted.forEach(c => gallery.appendChild(c));
    }

    // Initial paint
    applyFilters();
    sortCards(sortSel.value);

    // Persist + URL sync
    function updateStateAndURL(){
      const params = new URLSearchParams();
      if(activeFilter && activeFilter!=='all') params.set('cat', activeFilter);
      if(search.value) params.set('q', search.value);
      if(sortSel.value && sortSel.value!=='recent') params.set('sort', sortSel.value);
      const url = `${location.pathname}?${params.toString()}`;
      history.replaceState(null,'', url);

      localStorage.setItem('ek-cat', activeFilter);
      localStorage.setItem('ek-q', search.value);
      localStorage.setItem('ek-sort', sortSel.value);
    }

    shareView.addEventListener('click', async ()=>{
      await navigator.clipboard.writeText(location.href);
      showToast(getI18n('toastView'));
    });

    // ---------- Lightbox ----------
    const lb        = $('#lightbox');
    const lbPlayer  = $('#lb-player');
    const lbTitle   = $('#lb-title');
    const lbPrevBtn = $('#lb-prev');
    const lbNextBtn = $('#lb-next');
    const lbShare   = $('#lb-share');
    let currentIndex = -1;
    function currentVisibleCards(){ return $$('.card', gallery).filter(c => c.style.display !== 'none'); }

    function openLightbox({type, id, src, title}, index){
      lbTitle.textContent = title || 'Playing…';
      lb.classList.add('active');
      currentIndex = index;
      if(type === 'youtube'){
        const url = `https://www.youtube.com/embed/${id}?autoplay=1&mute=0&rel=0`;
        lbPlayer.innerHTML = `<iframe title="YouTube video" src="${url}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;
      } else if(type === 'mp4'){
        lbPlayer.innerHTML = `<video src="${src}" controls autoplay playsinline></video>`;
      }
      document.body.style.overflow = 'hidden';

      // Deep-link to this item
      const card = currentVisibleCards()[currentIndex];
      if(card && card.id){
        history.replaceState(null,'', `${location.pathname}${location.search}#${card.id}`);
      }
    }

    function closeLightbox(){
      lb.classList.remove('active');
      lbPlayer.innerHTML = '';
      document.body.style.overflow = '';
      // Remove hash but keep search params
      history.replaceState(null,'', `${location.pathname}${location.search}`);
    }

    function stepLightbox(dir){
      const vis = currentVisibleCards();
      if(!vis.length) return;
      currentIndex = (currentIndex + dir + vis.length) % vis.length;
      const nextCard = vis[currentIndex];
      const btn = $('.play-btn', nextCard);
      openLightbox({type:btn.dataset.type, id:btn.dataset.id, src:btn.dataset.src, title:btn.dataset.title}, currentIndex);
    }

    lb.addEventListener('click', (e) => { if(e.target.hasAttribute('data-close')) closeLightbox(); });
    document.addEventListener('keydown', (e) => {
      if(lb.classList.contains('active')){
        if(e.key === 'Escape') closeLightbox();
        if(e.key === 'ArrowLeft')  stepLightbox(-1);
        if(e.key === 'ArrowRight') stepLightbox(+1);
      }
    });
    lbPrevBtn.addEventListener('click', ()=>stepLightbox(-1));
    lbNextBtn.addEventListener('click', ()=>stepLightbox(+1));
    lbShare.addEventListener('click', async ()=>{
      await navigator.clipboard.writeText(location.href);
      showToast(getI18n('toastVideo'));
    });

    // Bind play buttons
    $$('.play-btn').forEach((btn, i) => btn.addEventListener('click', () => {
      const visible = currentVisibleCards();
      // Determine the index among visible cards
      const index = visible.indexOf(btn.closest('.card'));
      openLightbox({
        type: btn.dataset.type,
        id:   btn.dataset.id,
        src:  btn.dataset.src,
        title:btn.dataset.title || 'Playing…'
      }, index >= 0 ? index : i);
    }));

    // Open from hash (deep-link)
    window.addEventListener('load', ()=>{
      const id = location.hash.replace('#','');
      if(id){
        const card = document.getElementById(id);
        if(card){
          const btn = $('.play-btn', card);
          if(btn){ setTimeout(()=>btn.click(), 80); }
        }
      }
    });

    // ---------- Toast ----------
    function showToast(msg){
      const t = $('#toast');
      t.textContent = msg;
      t.classList.remove('show');
      // Force reflow to restart animation
      void t.offsetWidth;
      t.classList.add('show');
      setTimeout(()=>t.classList.remove('show'), 2200);
    }

    // ---------- Simple i18n (Translator) ----------
    const translations = {
      en: {
        brandTitle: "Editkaro.in • Portfolio",
        navHome: "Home", navWork: "Work", navCategories: "Categories", navAbout: "About", navServices: "Services", navContact: "Contact",
        ctaContact: "Contact",
        heroTitle: "We Edit. We Create. We Inspire.",
        heroSubtitle: "Social-first video editing, high-converting ads, gaming highlights, football edits, documentary styles, cinematic color grading, anime AMVs and brand storytelling — built for reach and retention.",
        viewWork: "View Our Work",
        btnShareView: "Share view",
        sortNewest: "Sort: Newest", sortOldest: "Sort: Oldest", sortAZ: "Sort: A–Z", sortZA: "Sort: Z–A",
        catAll: "All", catShort: "Short-form", catLong: "Long-form", catGaming: "Gaming", catFootball: "Football", catEcom: "eCommerce Ads", catDocu: "Documentary", catGrading: "Color Grading", catAnime: "Anime", reset: "Reset",
        tipKeys: "• Tip: use ↑/↓ to change sort, ←/→ to navigate videos in the lightbox.",
        pillShort: "Short-form", pillLong: "Long-form", pillGaming: "Gaming", pillFootball: "Football", pillEcom: "eCommerce Ad", pillDocu: "Documentary", pillGrading: "Color Grading", pillAnime: "Anime", pillBrand: "Brand Ad",
        play: "Play",
        noResults: "No results. Try a different keyword or category.",
        aboutTitle: "About Us",
        aboutLead: "We are Editkaro.in — a creative studio obsessed with scroll‑stopping content. From performance‑driven ad creatives to long‑form storytelling, we craft edits that make people watch, think and act. Our toolkit blends editorial sense, sound design, color science and motion to deliver results across platforms.",
        servicesTitle: "Our Services",
        servicesLead: "From viral hooks to cinematic color, we deliver end-to-end edits for growth.",
        svc1: "Short & Long Form Video Editing", svc2: "Social Media Marketing", svc3: "E-commerce & Ad Campaigns", svc4: "Color Grading & VFX",
        classicTitle: "Classic Grid Snapshots", classicLead: "A lightweight preview grid alongside the interactive gallery above.",
        classic1: "Short Form Video", classic2: "Gaming Edit", classic3: "E-commerce Ad", classic4: "Documentary Style",
        contactTitle: "Contact Us", contactLead: "Have a project? Tell us about your brand, goals and timeline.",
        phName: "Your Name", phEmail: "Your Email", phMessage: "Your Message", btnSend: "Send Message",
        prev: "◀ Prev", next: "Next ▶", btnShareVideo: "Share",
        toastThanks: "Thanks! We will get back to you.",
        toastView: "View link copied!",
        toastVideo: "Video link copied!",
        footerBrand: "Editkaro.in",
        footerLine: "Built for web & mobile • "
      },
      hi: {
        brandTitle: "Editkaro.in • पोर्टफोलियो",
        navHome: "होम", navWork: "वर्क", navCategories: "श्रेणियाँ", navAbout: "हमारे बारे में", navServices: "सेवाएँ", navContact: "संपर्क",
        ctaContact: "संपर्क",
        heroTitle: "We Edit. We Create. We Inspire.",
        heroSubtitle: "सोशल‑फर्स्ट वीडियो एडिटिंग, हाई‑कन्वर्टिंग ऐड्स, गेमिंग हाइलाइट्स, फुटबॉल एडिट्स, डॉक्यूमेंट्री स्टाइल्स, सिनेमैटिक कलर ग्रेडिंग, एनीमे AMVs और ब्रांड स्टोरीटेलिंग — रीच और रिटेंशन के लिए।",
        viewWork: "हमारा काम देखें",
        btnShareView: "व्यू साझा करें",
        sortNewest: "सॉर्ट: नया", sortOldest: "सॉर्ट: पुराना", sortAZ: "सॉर्ट: A–Z", sortZA: "सॉर्ट: Z–A",
        catAll: "सभी", catShort: "शॉर्ट‑फॉर्म", catLong: "लॉन्ग‑फॉर्म", catGaming: "गेमिंग", catFootball: "फुटबॉल", catEcom: "ईकॉमर्स ऐड्स", catDocu: "डॉक्यूमेंट्री", catGrading: "कलर ग्रेडिंग", catAnime: "ऐनिमे", reset: "रीसेट",
        tipKeys: "• टिप: ↑/↓ से सॉर्ट बदलें, ←/→ से लाइटबॉक्स में वीडियो नेविगेट करें।",
        pillShort: "शॉर्ट‑फॉर्म", pillLong: "लॉन्ग‑फॉर्म", pillGaming: "गेमिंग", pillFootball: "फुटबॉल", pillEcom: "ईकॉमर्स ऐड", pillDocu: "डॉक्यूमेंट्री", pillGrading: "कलर ग्रेडिंग", pillAnime: "ऐनिमे", pillBrand: "ब्रांड ऐड",
        play: "प्ले",
        noResults: "कोई परिणाम नहीं। एक अलग कीवर्ड या श्रेणी आज़माएँ।",
        aboutTitle: "हमारे बारे में",
        aboutLead: "हम Editkaro.in हैं—एक क्रिएटिव स्टूडियो जो स्क्रॉल‑स्टॉपिंग कंटेंट के लिए जुनूनी है। परफॉर्मेंस‑ड्रिवन ऐड क्रिएटिव्स से लेकर लॉन्ग‑फॉर्म स्टोरीटेलिंग तक, हम ऐसे एडिट बनाते हैं जो लोगों को देखने, सोचने और कार्रवाई करने पर मजबूर करें।",
        servicesTitle: "हमारी सेवाएँ",
        servicesLead: "वायरल हुक से सिनेमैटिक कलर तक, हम ग्रोथ के लिए एंड‑टू‑एंड एडिट्स डिलीवर करते हैं।",
        svc1: "शॉर्ट व लॉन्ग फॉर्म वीडियो एडिटिंग", svc2: "सोशल मीडिया मार्केटिंग", svc3: "ई‑कॉमर्स व ऐड कैंपेन", svc4: "कलर ग्रेडिंग व VFX",
        classicTitle: "क्लासिक ग्रिड स्नैपशॉट्स", classicLead: "ऊपर दिए इंटरैक्टिव गैलरी के साथ एक हल्का प्रीव्यू ग्रिड।",
        classic1: "शॉर्ट फॉर्म वीडियो", classic2: "गेमिंग एडिट", classic3: "ई‑कॉमर्स ऐड", classic4: "डॉक्यूमेंट्री स्टाइल",
        contactTitle: "संपर्क करें", contactLead: "कोई प्रोजेक्ट है? अपने ब्रांड, लक्ष्यों और टाइमलाइन के बारे में बताएं।",
        phName: "आपका नाम", phEmail: "आपका ईमेल", phMessage: "आपका संदेश", btnSend: "संदेश भेजें",
        prev: "◀ पिछला", next: "अगला ▶", btnShareVideo: "शेयर",
        toastThanks: "धन्यवाद! हम आपसे संपर्क करेंगे।",
        toastView: "व्यू लिंक कॉपी हो गया!",
        toastVideo: "वीडियो लिंक कॉपी हो गया!",
        footerBrand: "Editkaro.in",
        footerLine: "वेब व मोबाइल के लिए बना • HTML, CSS और JS से निर्मित"
      },
      es: {
        brandTitle: "Editkaro.in • Portafolio",
        navHome: "Inicio", navWork: "Trabajos", navCategories: "Categorías", navAbout: "Sobre nosotros", navServices: "Servicios", navContact: "Contacto",
        ctaContact: "Contacto",
        heroTitle: "Editamos. Creamos. Inspiramos.",
        heroSubtitle: "Edición de video para redes, anuncios que convierten, highlights de gaming, ediciones de fútbol, estilos documentales, etalonaje cinematográfico, AMVs y storytelling de marca — hechos para alcance y retención.",
        viewWork: "Ver nuestro trabajo",
        btnShareView: "Compartir vista",
        sortNewest: "Ordenar: Más nuevo", sortOldest: "Ordenar: Más antiguo", sortAZ: "Ordenar: A–Z", sortZA: "Ordenar: Z–A",
        catAll: "Todos", catShort: "Formato corto", catLong: "Formato largo", catGaming: "Gaming", catFootball: "Fútbol", catEcom: "Anuncios eCommerce", catDocu: "Documental", catGrading: "Etalonaje", catAnime: "Anime", reset: "Restablecer",
        tipKeys: "• Consejo: usa ↑/↓ para cambiar orden y ←/→ para navegar videos en el lightbox.",
        pillShort: "Formato corto", pillLong: "Formato largo", pillGaming: "Gaming", pillFootball: "Fútbol", pillEcom: "Anuncio eCommerce", pillDocu: "Documental", pillGrading: "Etalonaje", pillAnime: "Anime", pillBrand: "Anuncio de marca",
        play: "Reproducir",
        noResults: "Sin resultados. Prueba otra palabra clave o categoría.",
        aboutTitle: "Sobre nosotros",
        aboutLead: "Somos Editkaro.in — un estudio creativo obsesionado con contenido que detiene el scroll. Desde anuncios de rendimiento hasta narrativa larga, hacemos ediciones que hacen que la gente mire, piense y actúe.",
        servicesTitle: "Nuestros servicios",
        servicesLead: "De ganchos virales a color cinematográfico, entregamos ediciones integrales orientadas al crecimiento.",
        svc1: "Edición de video corto y largo", svc2: "Marketing en redes sociales", svc3: "Campañas de e‑commerce y anuncios", svc4: "Etalonaje y VFX",
        classicTitle: "Instantáneas en cuadrícula", classicLead: "Una cuadrícula ligera junto a la galería interactiva.",
        classic1: "Video formato corto", classic2: "Edición gaming", classic3: "Anuncio e‑commerce", classic4: "Estilo documental",
        contactTitle: "Contáctanos", contactLead: "¿Tienes un proyecto? Cuéntanos sobre tu marca, metas y tiempos.",
        phName: "Tu nombre", phEmail: "Tu correo", phMessage: "Tu mensaje", btnSend: "Enviar mensaje",
        prev: "◀ Anterior", next: "Siguiente ▶", btnShareVideo: "Compartir",
        toastThanks: "¡Gracias! Te contactaremos.", toastView: "¡Enlace de vista copiado!", toastVideo: "¡Enlace del video copiado!",
        footerBrand: "Editkaro.in", footerLine: "Construido para web y móvil • Hecho con HTML, CSS y JS"
      },
      fr: {
        brandTitle: "Editkaro.in • Portfolio",
        navHome: "Accueil", navWork: "Réalisations", navCategories: "Catégories", navAbout: "À propos", navServices: "Services", navContact: "Contact",
        ctaContact: "Contact",
        heroTitle: "Nous éditons. Nous créons. Nous inspirons.",
        heroSubtitle: "Montage vidéo orienté réseaux, pubs performantes, highlights gaming, montages football, styles documentaires, étalonnage cinématographique, AMV et storytelling de marque — pensés pour l’audience et la rétention.",
        viewWork: "Voir nos travaux",
        btnShareView: "Partager la vue",
        sortNewest: "Trier : Plus récent", sortOldest: "Trier : Plus ancien", sortAZ: "Trier : A–Z", sortZA: "Trier : Z–A",
        catAll: "Tous", catShort: "Court", catLong: "Long", catGaming: "Gaming", catFootball: "Football", catEcom: "Pubs e‑commerce", catDocu: "Documentaire", catGrading: "Étalonnage", catAnime: "Anime", reset: "Réinitialiser",
        tipKeys: "• Astuce : ↑/↓ pour trier, ←/→ pour naviguer dans le lightbox.",
        pillShort: "Court", pillLong: "Long", pillGaming: "Gaming", pillFootball: "Football", pillEcom: "Pub e‑commerce", pillDocu: "Documentaire", pillGrading: "Étalonnage", pillAnime: "Anime", pillBrand: "Pub marque",
        play: "Lecture",
        noResults: "Aucun résultat. Essayez un autre mot-clé ou catégorie.",
        aboutTitle: "À propos",
        aboutLead: "Nous sommes Editkaro.in — un studio créatif obsédé par le contenu qui arrête le scroll. Des pubs performance à la narration longue, nous créons des montages qui font regarder, réfléchir et agir.",
        servicesTitle: "Nos services",
        servicesLead: "Des hooks viraux à la couleur ciné, nous livrons des montages complets pour la croissance.",
        svc1: "Montage court et long", svc2: "Marketing social", svc3: "Campagnes e‑commerce & pubs", svc4: "Étalonnage & VFX",
        classicTitle: "Aperçus en grille", classicLead: "Une grille légère à côté de la galerie interactive.",
        classic1: "Vidéo court format", classic2: "Montage gaming", classic3: "Pub e‑commerce", classic4: "Style documentaire",
        contactTitle: "Nous contacter", contactLead: "Un projet ? Parlez‑nous de votre marque, objectifs et délais.",
        phName: "Votre nom", phEmail: "Votre email", phMessage: "Votre message", btnSend: "Envoyer",
        prev: "◀ Préc.", next: "Suiv. ▶", btnShareVideo: "Partager",
        toastThanks: "Merci ! Nous revenons vers vous.", toastView: "Lien de vue copié !", toastVideo: "Lien de la vidéo copié !",
        footerBrand: "Editkaro.in", footerLine: "Conçu pour le web & mobile • Réalisé en HTML, CSS & JS"
      }
    };

    const langSelect = $('#langSelect');
    const LS_LANG_KEY = 'ek-lang';

    function getI18n(key){
      const lang = localStorage.getItem(LS_LANG_KEY) || 'en';
      return (translations[lang] && translations[lang][key]) || (translations.en[key] || key);
    }

    function applyI18n(lang){
      // text nodes
      $$('[data-i18n]').forEach(el=>{
        const k = el.getAttribute('data-i18n');
        const t = translations[lang]?.[k] ?? translations.en[k] ?? el.textContent;
        el.textContent = t;
      });
      // placeholders
      $$('[data-i18n-placeholder]').forEach(el=>{
        const k = el.getAttribute('data-i18n-placeholder');
        const t = translations[lang]?.[k] ?? translations.en[k] ?? el.placeholder;
        el.placeholder = t;
      });
      // update select value to reflect
      langSelect.value = lang;
    }

    // init language
    (function initLang(){
      const saved = localStorage.getItem(LS_LANG_KEY) || 'en';
      applyI18n(saved);
      langSelect.value = saved;
    })();

    langSelect.addEventListener('change', ()=>{
      const lang = langSelect.value;
      localStorage.setItem(LS_LANG_KEY, lang);
      applyI18n(lang);
      // Update dynamic bits after language swap
      updateCategoryCounts();
      applyFilters();
      sortCards(sortSel.value);
    });